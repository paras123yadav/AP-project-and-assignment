function validate()                                   
{ 
    var yname = document.form.YName;   
    var fname = document.form.FName; 
    var mname = document.form.MName;
    var radio1 = document.getElementById("male").checked;
    var radio2 = document.getElementById("female").checked;
    var radio3 = document.getElementById("others").checked;             
    var email = document.form.EMail;    
    var phone = document.form.Telephone;
    var what =  document.form.Subject;  
    var password = document.form.Password; 
    var address = document.form.Address;   
   
    if (yname.value == "")                                  
    { 
        window.alert("Please enter your name."); 
        yname.focus(); 
        return false; 
    } 
    if (fname.value == "")                                  
    { 
        window.alert("Please enter your father's name."); 
        fname.focus(); 
        return false; 
    } 
   
    if (mname.value == "")                                  
    { 
        window.alert("Please enter your mother's name."); 
        mname.focus(); 
        return false; 
    } 
    if ((radio1 == "") && (radio2=="") && (radio3==""))                                   
    { 
        window.alert("Please select your gender.");  
        return false; 
    } 
   
    if (address.value == "")                               
    { 
        window.alert("Please enter your address."); 
        address.focus(); 
        return false; 
    } 
       
    if (email.value == "")                                   
    { 
        window.alert("Please enter a valid e-mail address."); 
        email.focus(); 
        return false; 
        
    } 
    
    if (password.value == "")                        
    { 
        window.alert("Please enter your password"); 
        password.focus(); 
        return false; 
    } 
   
    if (phone.value == "")                           
    { 
        window.alert("Please enter your telephone number"); 
        phone.focus(); 
        return false; 
    } 
   
    if (what.selectedIndex < 1)                  
    { 
        alert("Please enter your course."); 
        what.focus(); 
        return false; 
    } 
   
    return ;
}