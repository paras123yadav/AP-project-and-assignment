<html> 
    <head> 
        <link rel="stylesheet" type="text/css" href="formstyle1.css">
    </head> 
       
    <body style="background-color:#006b96"> 
        <?php
            $YnameError = $FnameError = $MnameError = $GenderError = $AddressError = $EMailError = $PasswordError = $TelephoneError = $SubjectError="";
            $Yname = $Fname = $Mname = $Gender = $Address = $EMail = $Password = $Telephone = $Subject = $Comment ="";
            if ($_SERVER["REQUEST_METHOD"] == "POST") 
            {// validation of our form
                if (empty($_POST["Yname"])) {
                  $YnameError = "your name is required";
                } else {
                  $Yname = test_input($_POST["Yname"]);
                  if (!preg_match("/^[a-zA-Z ]*$/",$Yname)) {
                    $YnameError = "Only letters and white space allowed";
                  }
                }

                if (empty($_POST["Fname"])) {
                    $FnameError = "your father's name is required";
                  } else {
                    $Fname = test_input($_POST["Fname"]);
                    if (!preg_match("/^[a-zA-Z ]*$/",$Fname)) {
                      $FnameError = "Only letters and white space allowed";
                    }
                  }

                  if (empty($_POST["Mname"])) {
                    $MnameError = "your mother's name is required";
                  } else {
                    $Mname = test_input($_POST["Mname"]);
                    if (!preg_match("/^[a-zA-Z ]*$/",$Mname)) {
                      $MnameError = "Only letters and white space allowed";
                    }
                  }

                  if (empty($_POST["Gender"])) {
                    $GenderError = "your gender is required";
                  } else {
                    $Gender = test_input($_POST["Gender"]);
                  }

                  if (empty($_POST["Address"])) {
                    $Address = "";
                  } else {
                    $Address = test_input($_POST["Address"]);
                  }

                  if (empty($_POST["EMail"])) {
                    $EMailError = "Email is required";
                    } else {
                      $EMail = test_input($_POST["EMail"]);
                    }

                  if (empty($_POST["Password"])) {
                    $PasswordError = "password is required";
                  } else {
                    $Password = test_input($_POST["Password"]);
                    if(strlen($_POST["Password"]) <= '8') {
                      $PasswordError = "Your Password Must Contain At Least 8 Characters!";
                  }
                  }

                  if (empty($_POST["Telephone"])) {
                    $TelephoneError = "enter your phone number";
                  } else {
                    $Telephone = test_input($_POST["Telephone"]);
                    if (!preg_match("/^[0-9]{10}+$/",$Telephone)) {
                      $TelephoneError = "Invalid( must be equal to 10)";
                    }
                  }

                  if (empty($_POST["Subject"])) {
                    $SubjectError = "Select course";
                    } else {
                      $Subject = test_input($_POST["Subject"]);
                    }

                  if (empty($_POST["Comment"])) {
                    $Comment = "";
                  } else {
                    $Comment = test_input($_POST["Comment"]);
                  }
            }
            function test_input($data) {
                $data = trim($data);
                $data = stripslashes($data);
                $data = htmlspecialchars($data);
                return $data;
                }
        ?>
           
    <form name="RegForm" action="submit.php" method="post"> 
        <h1 style="text-align: center; color:#005b50;"> REGISTRATION FORM </h1><br>
        <img src="avatar1.png" style="margin-left: 38%;height:20%;width:25%"> <br><br>  
        <p class="error">* Required Information</p> 
        <p>Name: <span class="error">*</span><input type="text" size=65 name="Yname" class="box" placeholder="First and last" value="<?php if (isset($_POST["Yname"])){echo $Yname;} ?>" ><span class="error"> <br><?php echo $YnameError?> </span>  <br> </p>
        <p>Father's Name: <span class="error">*</span><input type="text" size=65 name="Fname" class="box" value="<?php if (isset($_POST["Fname"])){echo $Fname;} ?>"> <span class="error"> <br><?php echo $FnameError?> </span>  <br> </p>
        <p>Mother's Name: <span class="error">*</span><input type="text" size=65 name="Mname" class="box" value="<?php if (isset($_POST["Mname"])){echo $Mname;} ?>"> <span class="error"> <br><?php echo $MnameError?> </span>  <br> </p> 
        <div><label>Gender:<span class="error">*</span></label>
            <label for="male">Male</label>
            <input name="Gender" type="radio" value="Male" id="male"> 
            <label for="female">Female</label>
            <input name="Gender" type="radio" value="Male" id="female">
            <label for="others">Others</label>
            <input name="Gender" type="radio" value="Male" id="others">
        </div>   
        <span class="error"> <br><?php echo $GenderError?> </span>  <br>
        <p> Address: <input type="text" size=65 name="Address" class="box" value="<?php if (isset($_POST["Address"])){echo $Address;} ?>"> </p> <br>
        <p>E-mail Address: <span class="error">*</span> <input type="email" size=65 name="EMail" class="box" value="<?php if (isset($_POST["EMail"])){echo $EMail;} ?>"> <span class="error"> <br><?php echo $EMailError?> </span>  <br> </p>
         <p>Password: <span class="error">*</span> <input type="text" size=65 name="Password" class="box"> <span class="error"> <br><?php echo $PasswordError?> </span>  <br> </p>
        <p>Telephone: <span class="error">*</span> </textarea> <input type="phone" size=25 name="Telephone" class="box" value="<?php if (isset($_POST["Telephone"])){echo $Telephone;} ?>"> <span class="error"> <br><?php echo $TelephoneError?> </span>  <br> </p>
               
        <p>SELECT YOUR COURSE    
            <select type="text" value="" name="Subject"> 
                <option>Choose</option>
                <option>BTECH</option> 
                <option>BBA</option> 
                <option>BCA</option> 
                <option>B.COM</option> 
                <option>B.sc</option> 
            </select><span class="error">* <br><?php echo $SubjectError?> </span></p> <br><br> 
        <p>Comments:  <textarea cols="55" name="Comment" class="box">  </textarea></p> <br>
        <p><input type="submit" value="Submit"  name="Submit" id="submit">      
            <input type="reset" value="Reset"  name="Reset" id="reset">   
        </p>          
    </form> 
    </body> 
    </html> 