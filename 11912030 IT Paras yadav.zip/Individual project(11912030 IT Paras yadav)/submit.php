<?php
?>
<html>
<head>
    <title>page after submission</title>
    <style>
          
 .aftersubmission{     
    background-color:rgb(207, 235, 241);   
    border: 0px solid black; 
    border-radius: 20px; 
    padding: 2%;                               
    margin: 0 auto; 
    width: 600px;
}
#google{
    height: 50px;
    width:50px;
}
#h2{
    color: lightgreen;
}
#p{
    color: red;
}
    </style>
</head>
<body bgcolor="#00d2d3">
    <div class="aftersubmission">
    <h2 id="h2"> Your Response is Submitted Successfully</h2>
    <p id="p"> We will furthure inform you via Email</p> <br>
    <a href="https://www.google.co.in/"><span style="color: red; margin-left:90%;"><img id="google" src="download.png"></span></a>
    </div>
</body>
</html>